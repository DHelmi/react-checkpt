import React from "react";
import Card from "react-bootstrap/Card";

function Title({ title }) {
  return <Card.Title>{title}</Card.Title>;
}

export default Title;
